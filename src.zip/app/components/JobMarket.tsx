import { ArrowLeft, CheckCircle2 } from 'lucide-react';
import { useNavigate } from 'react-router';

export function JobMarket() {
  const navigate = useNavigate();

  const jobs = [
    {
      id: 1,
      title: 'Online Chat Support',
      platform: 'Platform: LK',
      reward: 5000,
      verified: false
    },
    {
      id: 2,
      title: 'Data Entry Specialist',
      platform: 'Platform: Tokopedia',
      reward: 5000,
      verified: true
    },
    {
      id: 3,
      title: 'Content Moderator',
      platform: 'Platform: Shopee',
      reward: 5000,
      verified: true
    },
    {
      id: 4,
      title: 'Virtual Assistant',
      platform: 'Platform: Gojek',
      reward: 5000,
      verified: false
    },
    {
      id: 5,
      title: 'Social Media Manager',
      platform: 'Platform: Bukalapak',
      reward: 5000,
      verified: false
    },
    {
      id: 6,
      title: 'Customer Service Rep',
      platform: 'Platform: Grab',
      reward: 5000,
      verified: false
    },
    {
      id: 7,
      title: 'Product Reviewer',
      platform: 'Platform: Lazada',
      reward: 5000,
      verified: false
    },
    {
      id: 8,
      title: 'Freelance Writer',
      platform: 'Platform: Medium',
      reward: 5000,
      verified: false
    }
  ];

  return (
    <>
      {/* Header */}
      <div className="px-6 py-4 flex items-center gap-4 border-b bg-white" style={{ borderColor: '#E9ECEF' }}>
        <button 
          onClick={() => navigate('/')} 
          className="flex items-center justify-center w-10 h-10 rounded-full transition-all hover:bg-gray-100 active:scale-95"
        >
          <ArrowLeft size={24} style={{ color: '#1E293B' }} />
        </button>
        <h1 className="text-xl" style={{ color: '#1E293B', fontWeight: '700' }}>
          Pekerjaan
        </h1>
      </div>

      {/* Job List */}
      <div className="flex-1 overflow-y-auto px-6 pt-3 pb-6" style={{ backgroundColor: '#F8F9FA' }}>
        <div className="space-y-2.5">
          {jobs.sort((a, b) => (b.verified ? 1 : 0) - (a.verified ? 1 : 0)).map((job) => (
            <div 
              key={job.id}
              className="p-3 rounded-xl transition-all"
              style={{ 
                backgroundColor: '#FFFFFF',
                boxShadow: '0 1px 3px rgba(0, 0, 0, 0.05)'
              }}
            >
              <div className="mb-2.5">
                <h3 className="text-base mb-1" style={{ color: '#1E293B', fontWeight: '700' }}>
                  {job.title}
                </h3>
                <div className="flex items-center gap-2 mb-2">
                  <p className="text-xs" style={{ color: '#64748B' }}>
                    {job.platform}
                  </p>
                  {job.verified && (
                    <div 
                      className="flex items-center gap-1 text-xs px-1.5 py-0.5 rounded-full" 
                      style={{ 
                        backgroundColor: '#DBEAFE', 
                        color: '#3B82F6',
                        fontWeight: '700'
                      }}
                    >
                      <CheckCircle2 size={11} />
                      RESMI
                    </div>
                  )}
                </div>
                <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg" style={{ backgroundColor: '#FFF7ED' }}>
                  <span style={{ fontSize: '14px' }}>💎</span>
                  <p className="text-sm" style={{ color: '#F97316', fontWeight: '700' }}>
                    {job.reward.toLocaleString('id-ID')}/hari
                  </p>
                  <span className="text-xs ml-auto" style={{ color: '#94A3B8' }}>
                    = Rp {(job.reward * 10).toLocaleString('id-ID')}
                  </span>
                </div>
              </div>
              <button 
                className="w-full py-2 rounded-lg transition-all active:scale-98"
                style={{ 
                  backgroundColor: 'transparent',
                  color: '#F97316',
                  fontWeight: '600',
                  fontSize: '14px',
                  border: '1.5px solid #F97316'
                }}
                onClick={() => navigate('/task-detail')}
              >
                Lihat Detail
              </button>
            </div>
          ))}
        </div>
      </div>

      <style>{`
        .active\\:scale-98:active {
          transform: scale(0.98);
        }
        .active\\:scale-95:active {
          transform: scale(0.95);
        }
      `}</style>
    </>
  );
}