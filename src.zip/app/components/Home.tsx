import { useState, useEffect } from 'react';
import { TrendingUp, Star } from 'lucide-react';
import { useNavigate } from 'react-router';
import { OnboardingTask } from './OnboardingTask';
import { RewardAnimation } from './RewardAnimation';
import { VIPInvitePopup } from './VIPInvitePopup';

export function HomePage() {
  const navigate = useNavigate();
  const [currentTime, setCurrentTime] = useState(new Date());
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [showReward, setShowReward] = useState(false);
  const [showVIPPopup, setShowVIPPopup] = useState(false);
  const [currentBalance, setCurrentBalance] = useState(0);
  const [animatingBalance, setAnimatingBalance] = useState(0);

  const withdrawalGoal = 20000; // in diamonds
  const progressPercentage = (animatingBalance / withdrawalGoal) * 100;

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    // Check if user is new (for demo, we'll check localStorage)
    const hasCompletedOnboarding = localStorage.getItem('onboardingCompleted');
    console.log('Checking onboarding status:', hasCompletedOnboarding);
    
    if (!hasCompletedOnboarding) {
      console.log('New user detected, showing onboarding in 0.5s');
      // Show onboarding after 0.5s
      const timer = setTimeout(() => {
        setShowOnboarding(true);
      }, 500);
      return () => clearTimeout(timer);
    } else {
      console.log('Existing user, loading balance');
      // Load existing balance
      const savedBalance = localStorage.getItem('userBalance');
      const balance = savedBalance ? parseInt(savedBalance) : 12500;
      setCurrentBalance(balance);
      setAnimatingBalance(balance);
    }
  }, []);

  const handleOnboardingComplete = (data: { gender: 'male' | 'female'; age: number }) => {
    console.log('User data:', data);
    
    // Save to backend/localStorage
    localStorage.setItem('onboardingCompleted', 'true');
    localStorage.setItem('userGender', data.gender);
    localStorage.setItem('userAge', data.age.toString());
    
    // Check if user qualifies for VIP (age 18-35, any gender)
    if (data.age >= 18 && data.age <= 35) {
      localStorage.setItem('vipQualified', 'true');
    }
    
    // Close onboarding
    setShowOnboarding(false);
    
    // Show reward animation
    setShowReward(true);
    
    // Animate balance from 0 to 1000
    const targetBalance = 1000;
    setCurrentBalance(targetBalance);
    localStorage.setItem('userBalance', targetBalance.toString());
    
    // Animate balance counting
    let startBalance = 0;
    const duration = 2000;
    const steps = 60;
    const increment = targetBalance / steps;
    const stepDuration = duration / steps;
    
    const animateBalance = () => {
      let step = 0;
      const interval = setInterval(() => {
        step++;
        startBalance += increment;
        if (step >= steps) {
          setAnimatingBalance(targetBalance);
          clearInterval(interval);
        } else {
          setAnimatingBalance(Math.floor(startBalance));
        }
      }, stepDuration);
    };
    
    // Start balance animation after reward shows
    setTimeout(animateBalance, 500);
    
    // Show VIP popup for qualified users (female, 18-35 years old)
    if (data.gender === 'female' && data.age >= 18 && data.age <= 35) {
      // Check if VIP popup is not on cooldown
      const cooldownExpiry = localStorage.getItem('vipPopupCooldown');
      const now = Date.now();
      const shouldShow = !cooldownExpiry || now > parseInt(cooldownExpiry);
      
      if (shouldShow) {
        // Show VIP popup after reward animation (3 seconds)
        setTimeout(() => {
          setShowVIPPopup(true);
        }, 3000);
      }
    }
  };

  const tasks = [
    { id: 1, name: 'Isi survei kepuasan pelanggan', reward: 500, link: '/survey' },
    { id: 2, name: 'Unduh aplikasi dan daftar', reward: 800, link: '/download-app' },
    { id: 3, name: 'Tonton video 3 menit', reward: 250, link: '/watch-video' },
    { id: 4, name: 'Review produk di marketplace', reward: 700, link: '/product-review' },
  ];

  // Check if user is qualified for VIP task
  const isVIPQualified = localStorage.getItem('vipQualified') === 'true';
  
  // Add VIP task if qualified
  const allTasks = isVIPQualified 
    ? [
        { 
          id: 999, 
          name: 'VIP Host - Chat & Video dengan Pengguna Global', 
          reward: 5000, 
          link: '/vip-task-detail',
          isVIP: true 
        },
        ...tasks
      ]
    : tasks;

  const getRewardLevel = (reward: number) => {
    if (reward >= 5000) return { level: 'S', color: '#F97316', bgColor: '#FFF7ED' };
    if (reward >= 800) return { level: 'A', color: '#10B981', bgColor: '#F0FDF4' };
    if (reward >= 500) return { level: 'B', color: '#3B82F6', bgColor: '#EFF6FF' };
    return { level: 'C', color: '#94A3B8', bgColor: '#F8F9FA' };
  };

  const handleWithdrawal = () => {
    navigate('/withdrawal');
  };

  return (
    <>
      {/* Status Bar */}
      <div className="px-6 pt-3 pb-2 flex items-center justify-between text-sm" style={{ color: '#1E293B' }}>
        <span>{currentTime.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}</span>
        <div className="flex items-center gap-1">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <rect x="1" y="6" width="18" height="12" rx="2" />
            <path d="M23 13v-2" />
          </svg>
        </div>
      </div>

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto" style={{ backgroundColor: '#F8F9FA' }}>
        {/* Balance Card */}
        <div className="px-6 mb-4 pt-3">
          <div 
            className="bg-white rounded-2xl overflow-hidden transition-shadow"
            style={{ 
              boxShadow: '0 2px 8px rgba(0, 0, 0, 0.04), 0 1px 2px rgba(0, 0, 0, 0.06)'
            }}
          >
            {/* Marquee - Integrated at top of card */}
            <div className="overflow-hidden" style={{ backgroundColor: '#FFF7ED', borderBottom: '1px solid #FED7AA' }}>
              <div className="py-1.5 px-4 flex items-center gap-2 animate-marquee whitespace-nowrap">
                <TrendingUp size={12} style={{ color: '#F97316' }} />
                <span className="text-xs" style={{ color: '#EA580C', fontWeight: '500' }}>
                  Siti menarik Rp 50.000 via DANA • Ahmad menarik Rp 100.000 via OVO • Rina menarik Rp 75.000 via GoPay
                </span>
              </div>
            </div>

            {/* Balance Content */}
            <div className="px-5 pt-4 pb-4">
              <div className="text-xs mb-1.5" style={{ color: '#64748B' }}>Saldo Anda</div>
              <div className="flex items-center gap-2 mb-3.5">
                <span style={{ fontSize: '28px' }}>💎</span>
                <div className="text-3xl" style={{ color: '#F97316', fontWeight: '700' }}>
                  {animatingBalance.toLocaleString('id-ID')}
                </div>
                <div className="text-sm" style={{ color: '#94A3B8' }}>
                  = Rp {(animatingBalance * 10).toLocaleString('id-ID')}
                </div>
              </div>
              
              {/* Progress Bar Section */}
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs" style={{ color: '#64748B', fontWeight: '600' }}>
                    Progress Penarikan
                  </span>
                  <span className="text-xs px-2 py-0.5 rounded-full" style={{ color: '#F97316', backgroundColor: '#FFF7ED', fontWeight: '700' }}>
                    {Math.round(progressPercentage)}%
                  </span>
                </div>
                
                {/* Progress Bar */}
                <div className="w-full h-2.5 rounded-full mb-2" style={{ backgroundColor: '#E9ECEF' }}>
                  <div 
                    className="h-full rounded-full transition-all duration-500 ease-out"
                    style={{ 
                      backgroundColor: '#F97316',
                      width: `${progressPercentage}%`,
                      boxShadow: progressPercentage > 0 ? '0 0 8px rgba(249, 115, 22, 0.3)' : 'none'
                    }}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-xs" style={{ color: '#94A3B8' }}>
                    💎 {animatingBalance.toLocaleString('id-ID')}
                  </span>
                  <span className="text-xs" style={{ color: '#94A3B8' }}>
                    Target: 💎 {withdrawalGoal.toLocaleString('id-ID')}
                  </span>
                </div>
              </div>
              
              <button 
                className="w-full py-3 rounded-xl text-white transition-all active:scale-98"
                style={{ 
                  backgroundColor: '#F97316',
                  fontWeight: '600',
                  boxShadow: '0 2px 8px rgba(249, 115, 22, 0.25)'
                }}
                onClick={handleWithdrawal}
              >
                Tarik Tunai
              </button>
            </div>
          </div>
        </div>

        {/* Task Section */}
        <div className="px-6 pb-6">
          <h2 className="text-lg mb-3" style={{ color: '#1E293B', fontWeight: '700' }}>
            Tugas untuk Anda
          </h2>
          <div className="space-y-3">
            {allTasks.sort((a, b) => b.reward - a.reward).map(task => {
              const levelInfo = getRewardLevel(task.reward);
              const isSLevel = levelInfo.level === 'S';
              const isVIPTask = 'isVIP' in task && task.isVIP;
              
              return (
                <div 
                  key={task.id}
                  className="rounded-xl overflow-hidden transition-all"
                  style={{ 
                    backgroundColor: '#FFFFFF',
                    boxShadow: isVIPTask 
                      ? '0 4px 16px rgba(249, 115, 22, 0.25), 0 0 0 2px #F97316' 
                      : '0 1px 3px rgba(0, 0, 0, 0.05)',
                    position: 'relative'
                  }}
                >
                  {/* VIP Special Banner */}
                  {isVIPTask && (
                    <div className="px-4 py-2 flex items-center gap-2 relative overflow-hidden" style={{ 
                      background: 'linear-gradient(135deg, #DC2626 0%, #F97316 100%)',
                      boxShadow: '0 2px 4px rgba(249, 115, 22, 0.3)'
                    }}>
                      {/* Animated shine */}
                      <div 
                        className="absolute inset-0 animate-shine-banner"
                        style={{
                          background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent)',
                        }}
                      />
                      
                      <Star size={14} style={{ color: '#FFFFFF' }} fill="#FFFFFF" />
                      <span className="text-xs" style={{ color: '#FFFFFF', fontWeight: '800', letterSpacing: '0.5px' }}>
                        VIP EKSKLUSIF
                      </span>
                    </div>
                  )}
                  
                  {/* Regular S Level Banner */}
                  {isSLevel && !isVIPTask && (
                    <div className="px-4 py-2 flex items-center gap-2" style={{ 
                      background: 'linear-gradient(135deg, #F97316 0%, #FB923C 100%)',
                      boxShadow: '0 2px 4px rgba(249, 115, 22, 0.2)'
                    }}>
                      <span className="text-xs" style={{ color: '#FFFFFF', fontWeight: '700' }}>LEVEL S</span>
                      <Star size={12} style={{ color: '#FFFFFF' }} fill="#FFFFFF" />
                      <span className="text-xs ml-auto" style={{ color: '#FFF7ED', fontWeight: '500' }}>Reward Tertinggi</span>
                    </div>
                  )}
                  
                  <div className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1 pr-4">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="text-sm leading-snug" style={{ 
                            color: '#1E293B', 
                            fontWeight: isVIPTask ? '700' : '500' 
                          }}>
                            {task.name}
                          </span>
                          {!isSLevel && !isVIPTask && (
                            <div 
                              className="rounded flex items-center justify-center flex-shrink-0"
                              style={{ 
                                backgroundColor: levelInfo.bgColor,
                                width: '28px',
                                height: '28px',
                                boxShadow: '0 1px 2px rgba(0, 0, 0, 0.05)'
                              }}
                            >
                              <span 
                                style={{ 
                                  color: levelInfo.color, 
                                  fontWeight: '700',
                                  fontSize: '13px'
                                }}
                              >
                                {levelInfo.level}
                              </span>
                            </div>
                          )}
                        </div>
                        <div className="flex items-center gap-1.5">
                          <span style={{ fontSize: '18px' }}>💎</span>
                          <span className="text-lg" style={{ 
                            color: '#F97316', 
                            fontWeight: '700',
                            fontSize: isVIPTask ? '20px' : '18px'
                          }}>
                            {task.reward.toLocaleString('id-ID')}
                          </span>
                        </div>
                      </div>
                    </div>
                    <button 
                      className="w-full py-2.5 rounded-lg transition-all active:scale-98"
                      style={{ 
                        backgroundColor: isVIPTask ? '#F97316' : 'transparent',
                        color: isVIPTask ? '#FFFFFF' : '#F97316',
                        fontWeight: isVIPTask ? '700' : '600',
                        border: isVIPTask ? 'none' : '1.5px solid #F97316',
                        boxShadow: isVIPTask ? '0 4px 12px rgba(249, 115, 22, 0.3)' : 'none'
                      }}
                      onClick={() => {
                        if (isVIPTask) {
                          setShowVIPPopup(true);
                        } else if (task.link) {
                          navigate(task.link);
                        }
                      }}
                    >
                      {isVIPTask ? '💬 Lihat Detail' : 'Kerjakan'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <style>{`
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
        .animate-marquee {
          animation: marquee 20s linear infinite;
        }
        .active\:scale-98:active {
          transform: scale(0.98);
        }
        .active\:scale-95:active {
          transform: scale(0.95);
        }
        @keyframes shine-banner {
          0% { left: -100%; }
          100% { left: 100%; }
        }
        .animate-shine-banner {
          animation: shine-banner 3s infinite;
        }
      `}</style>

      {/* Onboarding Task */}
      <OnboardingTask 
        isOpen={showOnboarding} 
        onComplete={handleOnboardingComplete} 
      />

      {/* Reward Animation */}
      <RewardAnimation 
        amount={1000}
        isVisible={showReward}
        onComplete={() => setShowReward(false)}
      />

      {/* VIP Invite Popup */}
      <VIPInvitePopup 
        isOpen={showVIPPopup}
        onAccept={() => {
          setShowVIPPopup(false);
          navigate('/vip-task-detail');
        }}
        onClose={() => setShowVIPPopup(false)}
      />
    </>
  );
}