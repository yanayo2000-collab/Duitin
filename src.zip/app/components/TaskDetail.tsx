import { ArrowLeft, Clock, CheckCircle2, AlertCircle, ChevronRight } from 'lucide-react';
import { useNavigate } from 'react-router';

export function TaskDetail() {
  const navigate = useNavigate();

  const steps = [
    { id: 1, title: 'Buka aplikasi Tokopedia', completed: true },
    { id: 2, title: 'Cari produk "Skincare"', completed: true },
    { id: 3, title: 'Pilih 3 produk berbeda', completed: false },
    { id: 4, title: 'Screenshot dan upload', completed: false },
  ];

  return (
    <>
      {/* Header */}
      <div className="px-6 py-4 flex items-center gap-4 border-b bg-white" style={{ borderColor: '#E9ECEF' }}>
        <button 
          onClick={() => navigate('/tasks')} 
          className="flex items-center justify-center w-10 h-10 rounded-full transition-all hover:bg-gray-100 active:scale-95"
        >
          <ArrowLeft size={24} style={{ color: '#1E293B' }} />
        </button>
        <h1 className="text-xl" style={{ color: '#1E293B', fontWeight: '700' }}>
          Detail Tugas
        </h1>
      </div>

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto" style={{ backgroundColor: '#F8F9FA' }}>
        {/* Task Header */}
        <div className="px-6 py-6 bg-white mb-4">
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <h2 className="text-lg mb-2" style={{ color: '#1E293B', fontWeight: '700' }}>
                Data Entry Specialist
              </h2>
              <div className="flex items-center gap-2 mb-3">
                <span className="text-sm" style={{ color: '#64748B' }}>
                  Platform: Tokopedia
                </span>
                <div 
                  className="flex items-center gap-1 text-xs px-2 py-1 rounded-full" 
                  style={{ 
                    backgroundColor: '#DBEAFE', 
                    color: '#3B82F6',
                    fontWeight: '700'
                  }}
                >
                  <CheckCircle2 size={12} />
                  RESMI
                </div>
              </div>
            </div>
          </div>

          {/* Reward Card */}
          <div 
            className="p-4 rounded-xl mb-4"
            style={{ 
              background: 'linear-gradient(135deg, #F97316 0%, #FB923C 100%)',
              boxShadow: '0 4px 12px rgba(249, 115, 22, 0.3)'
            }}
          >
            <div className="text-xs mb-1" style={{ color: '#FFF7ED', fontWeight: '600' }}>
              REWARD
            </div>
            <div className="flex items-center gap-2">
              <span style={{ fontSize: '24px' }}>💎</span>
              <span className="text-3xl" style={{ color: '#FFFFFF', fontWeight: '700' }}>
                5.000
              </span>
              <span className="text-sm ml-auto" style={{ color: '#FFF7ED' }}>
                = Rp 50.000
              </span>
            </div>
          </div>

          {/* Time Info */}
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <Clock size={16} style={{ color: '#64748B' }} />
              <div>
                <div className="text-xs" style={{ color: '#64748B' }}>
                  Estimasi
                </div>
                <div className="text-sm" style={{ color: '#1E293B', fontWeight: '600' }}>
                  15-30 menit
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <AlertCircle size={16} style={{ color: '#64748B' }} />
              <div>
                <div className="text-xs" style={{ color: '#64748B' }}>
                  Deadline
                </div>
                <div className="text-sm" style={{ color: '#1E293B', fontWeight: '600' }}>
                  3 hari lagi
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Description */}
        <div className="px-6 pb-4">
          <h3 className="text-sm mb-3" style={{ color: '#64748B', fontWeight: '600' }}>
            DESKRIPSI TUGAS
          </h3>
          <div 
            className="p-4 rounded-xl"
            style={{ 
              backgroundColor: '#FFFFFF',
              boxShadow: '0 1px 3px rgba(0, 0, 0, 0.05)'
            }}
          >
            <p className="text-sm leading-relaxed" style={{ color: '#1E293B' }}>
              Bantu kami melakukan riset produk di platform Tokopedia. Anda akan diminta untuk mencari kategori produk tertentu, memilih beberapa produk, dan mendokumentasikan hasilnya.
            </p>
          </div>
        </div>

        {/* Steps */}
        <div className="px-6 pb-4">
          <h3 className="text-sm mb-3" style={{ color: '#64748B', fontWeight: '600' }}>
            LANGKAH-LANGKAH
          </h3>
          <div className="space-y-2">
            {steps.map((step, index) => (
              <div 
                key={step.id}
                className="p-4 rounded-xl flex items-center gap-3"
                style={{ 
                  backgroundColor: '#FFFFFF',
                  boxShadow: '0 1px 3px rgba(0, 0, 0, 0.05)'
                }}
              >
                <div 
                  className="flex items-center justify-center w-8 h-8 rounded-full flex-shrink-0"
                  style={{ 
                    backgroundColor: step.completed ? '#F0FDF4' : '#F8F9FA',
                    color: step.completed ? '#10B981' : '#94A3B8',
                    fontWeight: '700',
                    fontSize: '14px'
                  }}
                >
                  {step.completed ? <CheckCircle2 size={18} style={{ color: '#10B981' }} /> : index + 1}
                </div>
                <span 
                  className="text-sm flex-1"
                  style={{ 
                    color: step.completed ? '#64748B' : '#1E293B',
                    textDecoration: step.completed ? 'line-through' : 'none'
                  }}
                >
                  {step.title}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Requirements */}
        <div className="px-6 pb-6">
          <h3 className="text-sm mb-3" style={{ color: '#64748B', fontWeight: '600' }}>
            PERSYARATAN
          </h3>
          <div 
            className="p-4 rounded-xl"
            style={{ 
              backgroundColor: '#FFFFFF',
              boxShadow: '0 1px 3px rgba(0, 0, 0, 0.05)'
            }}
          >
            <ul className="space-y-2">
              <li className="flex items-start gap-2">
                <CheckCircle2 size={16} className="mt-0.5 flex-shrink-0" style={{ color: '#10B981' }} />
                <span className="text-sm" style={{ color: '#1E293B' }}>
                  Memiliki akun Tokopedia aktif
                </span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 size={16} className="mt-0.5 flex-shrink-0" style={{ color: '#10B981' }} />
                <span className="text-sm" style={{ color: '#1E293B' }}>
                  Smartphone dengan koneksi internet stabil
                </span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 size={16} className="mt-0.5 flex-shrink-0" style={{ color: '#10B981' }} />
                <span className="text-sm" style={{ color: '#1E293B' }}>
                  Dapat mengambil dan mengupload screenshot
                </span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Action */}
      <div 
        className="px-6 py-4 border-t bg-white"
        style={{ borderColor: '#E9ECEF' }}
      >
        <button 
          className="w-full py-3 rounded-xl transition-all active:scale-98"
          style={{ 
            backgroundColor: '#F97316',
            color: '#FFFFFF',
            fontWeight: '600',
            boxShadow: '0 2px 8px rgba(249, 115, 22, 0.25)'
          }}
        >
          Mulai Tugas
        </button>
      </div>

      <style>{`
        .active\\:scale-98:active {
          transform: scale(0.98);
        }
        .active\\:scale-95:active {
          transform: scale(0.95);
        }
      `}</style>
    </>
  );
}
