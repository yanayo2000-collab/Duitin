import { ArrowLeft, Clock, Lock, CheckCircle2 } from 'lucide-react';
import { useNavigate } from 'react-router';
import { useState } from 'react';
import { WithdrawalSuccessModal } from './WithdrawalSuccessModal';
import { WithdrawalFailureModal } from './WithdrawalFailureModal';
import { WithdrawalProcessingOverlay } from './WithdrawalProcessingOverlay';

export function Withdrawal() {
  const navigate = useNavigate();
  const [selectedAmount, setSelectedAmount] = useState(10000);
  const [phoneNumber, setPhoneNumber] = useState('081234567890');
  const [accountName, setAccountName] = useState('Siti Aisyah');
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [showFailureModal, setShowFailureModal] = useState(false);
  const [failureReason, setFailureReason] = useState<'insufficient_balance' | 'account_invalid' | 'system_error' | 'daily_limit' | 'maintenance'>('system_error');
  const [isProcessing, setIsProcessing] = useState(false);
  
  const currentBalance = 12500; // in diamonds
  const withdrawalTiers = [10000, 20000, 50000, 100000];
  const isDisabled = selectedAmount > currentBalance || !phoneNumber || !accountName || isProcessing;

  const handleWithdrawal = () => {
    if (isDisabled) return;

    setIsProcessing(true);

    // Simulate API call with timeout
    setTimeout(() => {
      // Simulate different failure scenarios (for demo purposes)
      const random = Math.random();
      
      if (selectedAmount > currentBalance) {
        setFailureReason('insufficient_balance');
        setShowFailureModal(true);
      } else if (random < 0.15) { // 15% chance of account invalid
        setFailureReason('account_invalid');
        setShowFailureModal(true);
      } else if (random < 0.25) { // 10% chance of daily limit
        setFailureReason('daily_limit');
        setShowFailureModal(true);
      } else if (random < 0.3) { // 5% chance of maintenance
        setFailureReason('maintenance');
        setShowFailureModal(true);
      } else if (random < 0.35) { // 5% chance of system error
        setFailureReason('system_error');
        setShowFailureModal(true);
      } else {
        // Success
        setShowSuccessModal(true);
      }
      
      setIsProcessing(false);
    }, 1500);
  };

  const handleRetry = () => {
    setShowFailureModal(false);
  };

  const handleContactSupport = () => {
    setShowFailureModal(false);
    navigate('/customer-service');
  };

  const handleGoBack = () => {
    setShowFailureModal(false);
  };

  return (
    <>
      {/* Header */}
      <div className="px-6 py-4 flex items-center gap-4 border-b bg-white" style={{ borderColor: '#E9ECEF' }}>
        <button 
          onClick={() => navigate('/')} 
          className="flex items-center justify-center w-10 h-10 rounded-full transition-all hover:bg-gray-100 active:scale-95"
        >
          <ArrowLeft size={24} style={{ color: '#1E293B' }} />
        </button>
        <h1 className="text-xl" style={{ color: '#1E293B', fontWeight: '700' }}>
          Tarik Tunai
        </h1>
      </div>

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto px-6 py-3" style={{ backgroundColor: '#F8F9FA' }}>
        {/* Balance Display */}
        <div 
          className="mb-3 p-3 rounded-2xl"
          style={{ 
            backgroundColor: '#FFFFFF',
            boxShadow: '0 2px 8px rgba(0, 0, 0, 0.04), 0 1px 2px rgba(0, 0, 0, 0.06)'
          }}
        >
          <div className="text-xs mb-1" style={{ color: '#64748B', fontWeight: '600' }}>
            Saldo Tersedia
          </div>
          <div className="flex items-center gap-2">
            <span style={{ fontSize: '20px' }} className="diamond-pulse">💎</span>
            <div className="text-2xl" style={{ color: '#F97316', fontWeight: '700' }}>
              {currentBalance.toLocaleString('id-ID')}
            </div>
            <div className="text-xs" style={{ color: '#94A3B8' }}>
              = Rp {(currentBalance * 10).toLocaleString('id-ID')}
            </div>
          </div>
        </div>

        {/* Withdrawal Amount Section */}
        <div 
          className="mb-3 p-3 rounded-2xl"
          style={{ 
            backgroundColor: '#FFFFFF',
            boxShadow: '0 1px 3px rgba(0, 0, 0, 0.05)'
          }}
        >
          <label className="text-xs block mb-2" style={{ color: '#1E293B', fontWeight: '700' }}>
            Pilih Jumlah Penarikan
          </label>
          <div className="grid grid-cols-2 gap-2">
            {withdrawalTiers.map((tier) => {
              const isSelected = selectedAmount === tier;
              const isAvailable = tier <= currentBalance;
              return (
                <button
                  key={tier}
                  onClick={() => isAvailable && setSelectedAmount(tier)}
                  disabled={!isAvailable}
                  className="p-2.5 rounded-xl transition-all active:scale-95"
                  style={{
                    backgroundColor: isSelected ? '#FFF7ED' : '#F8F9FA',
                    border: isSelected ? '2px solid #F97316' : '2px solid transparent',
                    opacity: isAvailable ? 1 : 0.5,
                    cursor: isAvailable ? 'pointer' : 'not-allowed'
                  }}
                >
                  <div className="flex items-center justify-center gap-1 mb-0.5">
                    <span style={{ fontSize: '14px' }} className={isSelected ? 'diamond-bounce' : ''}>💎</span>
                    <span 
                      className="text-sm"
                      style={{ 
                        color: isSelected ? '#F97316' : '#1E293B',
                        fontWeight: '700'
                      }}
                    >
                      {tier.toLocaleString('id-ID')}
                    </span>
                  </div>
                  <div 
                    className="text-xs text-center"
                    style={{ 
                      color: isSelected ? '#F97316' : '#64748B',
                      fontWeight: '500'
                    }}
                  >
                    Rp {(tier * 10).toLocaleString('id-ID')}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Payment Method Section */}
        <div 
          className="mb-3 p-3 rounded-2xl"
          style={{ 
            backgroundColor: '#FFFFFF',
            boxShadow: '0 1px 3px rgba(0, 0, 0, 0.05)'
          }}
        >
          <label className="text-xs block mb-2" style={{ color: '#1E293B', fontWeight: '700' }}>
            Metode Penarikan
          </label>
          <div 
            className="flex items-center gap-3 p-2.5 rounded-xl" 
            style={{ 
              backgroundColor: '#FFF7ED',
              border: '2px solid #F97316'
            }}
          >
            <div className="flex items-center justify-center">
              <div className="w-5 h-5 rounded-full border-2 flex items-center justify-center" style={{ borderColor: '#F97316' }}>
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: '#F97316' }} />
              </div>
            </div>
            <span className="text-sm" style={{ color: '#F97316', fontWeight: '700' }}>DANA</span>
            <CheckCircle2 size={16} className="ml-auto" style={{ color: '#F97316' }} />
          </div>
        </div>

        {/* DANA Account Inputs */}
        <div 
          className="mb-3 p-3 rounded-2xl"
          style={{ 
            backgroundColor: '#FFFFFF',
            boxShadow: '0 1px 3px rgba(0, 0, 0, 0.05)'
          }}
        >
          <label className="text-xs block mb-2" style={{ color: '#1E293B', fontWeight: '700' }}>
            Nomor DANA
          </label>
          <input
            type="tel"
            placeholder="081234567890"
            value={phoneNumber}
            onChange={(e) => setPhoneNumber(e.target.value)}
            className="w-full px-3 py-2 text-sm rounded-xl mb-2.5 transition-all focus:outline-none"
            style={{ 
              color: '#1E293B',
              backgroundColor: '#F8F9FA',
              border: '2px solid transparent'
            }}
            onFocus={(e) => e.target.style.borderColor = '#F97316'}
            onBlur={(e) => e.target.style.borderColor = 'transparent'}
          />
          
          <label className="text-xs block mb-2" style={{ color: '#1E293B', fontWeight: '700' }}>
            Nama Akun DANA
          </label>
          <input
            type="text"
            placeholder="Siti Aisyah"
            value={accountName}
            onChange={(e) => setAccountName(e.target.value)}
            className="w-full px-3 py-2 text-sm rounded-xl transition-all focus:outline-none"
            style={{ 
              color: '#1E293B',
              backgroundColor: '#F8F9FA',
              border: '2px solid transparent'
            }}
            onFocus={(e) => e.target.style.borderColor = '#F97316'}
            onBlur={(e) => e.target.style.borderColor = 'transparent'}
          />
        </div>

        {/* Trust Elements */}
        <div 
          className="mb-3 p-2.5 rounded-xl space-y-1.5"
          style={{ 
            backgroundColor: '#FFFFFF',
            border: '1px solid #E9ECEF'
          }}
        >
          <div className="flex items-center gap-2">
            <div className="flex items-center justify-center w-6 h-6 rounded-full" style={{ backgroundColor: '#EFF6FF' }}>
              <Clock size={12} style={{ color: '#3B82F6' }} />
            </div>
            <span className="text-xs" style={{ color: '#64748B', fontWeight: '500' }}>
              Proses 1x24 jam
            </span>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center justify-center w-6 h-6 rounded-full" style={{ backgroundColor: '#F0FDF4' }}>
              <Lock size={12} style={{ color: '#10B981' }} />
            </div>
            <span className="text-xs" style={{ color: '#64748B', fontWeight: '500' }}>
              Data aman terenkripsi
            </span>
          </div>
        </div>

        {/* Submit Button */}
        <button 
          disabled={isDisabled}
          onClick={handleWithdrawal}
          className="w-full py-3 rounded-xl text-white transition-all active:scale-98"
          style={{ 
            backgroundColor: isDisabled ? '#CBD5E1' : '#F97316',
            cursor: isDisabled ? 'not-allowed' : 'pointer',
            fontWeight: '700',
            boxShadow: isDisabled ? 'none' : '0 2px 8px rgba(249, 115, 22, 0.25)'
          }}
        >
          {isProcessing ? 'Memproses...' : 'Ajukan Penarikan'}
        </button>
      </div>

      {/* Success Modal */}
      <WithdrawalSuccessModal
        isOpen={showSuccessModal}
        onClose={() => setShowSuccessModal(false)}
        amount={selectedAmount}
        destination="DANA"
        accountNumber={phoneNumber}
      />

      {/* Failure Modal */}
      <WithdrawalFailureModal
        isOpen={showFailureModal}
        onClose={() => setShowFailureModal(false)}
        amount={selectedAmount}
        failReason={failureReason}
        onRetry={handleRetry}
        onContactSupport={handleContactSupport}
        onGoBack={handleGoBack}
      />

      {/* Processing Overlay */}
      <WithdrawalProcessingOverlay
        isVisible={isProcessing}
      />

      <style>{`
        .active\\:scale-98:active {
          transform: scale(0.98);
        }
        .active\\:scale-95:active {
          transform: scale(0.95);
        }
        .diamond-pulse {
          animation: pulse 1.5s infinite;
        }
        .diamond-bounce {
          animation: bounce 1.5s infinite;
        }
        @keyframes pulse {
          0%, 100% {
            transform: scale(1);
          }
          50% {
            transform: scale(1.1);
          }
        }
        @keyframes bounce {
          0%, 100% {
            transform: translateY(0);
          }
          50% {
            transform: translateY(-5px);
          }
        }
      `}</style>
    </>
  );
}