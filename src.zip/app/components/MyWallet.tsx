import { ArrowLeft, TrendingUp, TrendingDown, Calendar, Wallet, FileText } from 'lucide-react';
import { useNavigate } from 'react-router';

export function MyWallet() {
  const navigate = useNavigate();
  
  const balance = 12500;
  const balanceRupiah = balance * 10;

  const transactions = [
    { 
      id: 1, 
      type: 'income', 
      title: 'Review produk di marketplace', 
      amount: 1500, 
      date: '9 Mar 2026',
      time: '14:30'
    },
    { 
      id: 2, 
      type: 'income', 
      title: 'Unduh aplikasi dan daftar', 
      amount: 800, 
      date: '9 Mar 2026',
      time: '11:15'
    },
    { 
      id: 3, 
      type: 'expense', 
      title: 'Penarikan ke DANA', 
      amount: 5000, 
      date: '8 Mar 2026',
      time: '16:45'
    },
    { 
      id: 4, 
      type: 'income', 
      title: 'Isi survei kepuasan pelanggan', 
      amount: 500, 
      date: '8 Mar 2026',
      time: '09:20'
    },
    { 
      id: 5, 
      type: 'income', 
      title: 'Bonus ajak teman', 
      amount: 500, 
      date: '7 Mar 2026',
      time: '18:30'
    },
    { 
      id: 6, 
      type: 'income', 
      title: 'Tonton video 3 menit', 
      amount: 250, 
      date: '7 Mar 2026',
      time: '13:00'
    },
    { 
      id: 7, 
      type: 'expense', 
      title: 'Penarikan ke DANA', 
      amount: 10000, 
      date: '6 Mar 2026',
      time: '10:15'
    },
  ];

  const totalIncome = transactions
    .filter(t => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalExpense = transactions
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);

  return (
    <>
      {/* Header */}
      <div className="px-6 py-4 flex items-center gap-4 border-b bg-white" style={{ borderColor: '#E9ECEF' }}>
        <button 
          onClick={() => navigate('/profile')} 
          className="flex items-center justify-center w-10 h-10 rounded-full transition-all hover:bg-gray-100 active:scale-95"
        >
          <ArrowLeft size={24} style={{ color: '#1E293B' }} />
        </button>
        <h1 className="text-xl" style={{ color: '#1E293B', fontWeight: '700' }}>
          Dompet Saya
        </h1>
      </div>

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto px-6 py-6" style={{ backgroundColor: '#F8F9FA' }}>
        {/* Balance Card with Withdraw Button */}
        <div 
          className="mb-6 p-5 rounded-2xl relative overflow-hidden"
          style={{ 
            background: 'linear-gradient(135deg, #F97316 0%, #FB923C 100%)',
            boxShadow: '0 4px 12px rgba(249, 115, 22, 0.25)'
          }}
        >
          {/* Withdrawal Details Button */}
          <button
            onClick={() => navigate('/history')}
            className="absolute top-4 right-4 p-2 rounded-lg transition-all active:scale-95"
            style={{
              backgroundColor: 'rgba(255, 255, 255, 0.2)',
              backdropFilter: 'blur(10px)'
            }}
          >
            <FileText size={18} style={{ color: '#FFFFFF' }} />
          </button>

          <div className="text-sm mb-2" style={{ color: '#FFF7ED', fontWeight: '500' }}>
            Total Saldo
          </div>
          <div className="flex items-center gap-2 mb-1">
            <span style={{ fontSize: '24px' }}>💎</span>
            <span className="text-3xl" style={{ color: '#FFFFFF', fontWeight: '700' }}>
              {balance.toLocaleString('id-ID')}
            </span>
          </div>
          <div className="text-sm mb-4" style={{ color: '#FFF7ED', fontWeight: '500' }}>
            = Rp {balanceRupiah.toLocaleString('id-ID')}
          </div>

          {/* Integrated Withdraw Button */}
          <button 
            onClick={() => navigate('/withdrawal')}
            className="w-full py-3 rounded-xl flex items-center justify-center gap-2 transition-all active:scale-98"
            style={{ 
              backgroundColor: '#FFFFFF',
              color: '#F97316',
              fontWeight: '700',
              boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)'
            }}
          >
            <Wallet size={20} />
            <span>Tarik Tunai</span>
          </button>
        </div>

        {/* Transactions */}
        <div>
          <div className="flex items-center gap-2 mb-4">
            <Calendar size={18} style={{ color: '#64748B' }} />
            <h3 className="text-base" style={{ color: '#1E293B', fontWeight: '700' }}>
              Riwayat Transaksi
            </h3>
          </div>
          
          <div className="space-y-3">
            {transactions.map((transaction) => (
              <div
                key={transaction.id}
                className="p-4 rounded-xl"
                style={{
                  backgroundColor: '#FFFFFF',
                  boxShadow: '0 1px 3px rgba(0, 0, 0, 0.05)'
                }}
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <div className="text-base mb-1" style={{ color: '#1E293B', fontWeight: '600' }}>
                      {transaction.title}
                    </div>
                    <div className="text-xs" style={{ color: '#94A3B8', fontWeight: '500' }}>
                      {transaction.date} • {transaction.time}
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <span style={{ fontSize: '16px' }}>💎</span>
                    <span 
                      className="text-lg"
                      style={{ 
                        color: transaction.type === 'income' ? '#10B981' : '#EF4444',
                        fontWeight: '700'
                      }}
                    >
                      {transaction.type === 'income' ? '+' : '-'}{transaction.amount.toLocaleString('id-ID')}
                    </span>
                  </div>
                </div>
                <div 
                  className="text-xs px-2 py-1 rounded-full inline-block"
                  style={{
                    backgroundColor: transaction.type === 'income' ? '#DCFCE7' : '#FEF2F2',
                    color: transaction.type === 'income' ? '#10B981' : '#EF4444',
                    fontWeight: '600'
                  }}
                >
                  {transaction.type === 'income' ? 'Pemasukan' : 'Penarikan'}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <style>{`
        .active\\:scale-98:active {
          transform: scale(0.98);
        }
        .active\\:scale-95:active {
          transform: scale(0.95);
        }
      `}</style>
    </>
  );
}