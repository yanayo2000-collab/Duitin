import { ArrowLeft, MessageCircle, HelpCircle, FileText, MessageSquare, Star } from 'lucide-react';
import { useNavigate } from 'react-router';

export function Services() {
  const navigate = useNavigate();

  const serviceItems = [
    { 
      id: 1, 
      icon: MessageCircle, 
      label: 'Chat Langsung', 
      description: 'Hubungi tim support kami',
      color: '#F97316', 
      bgColor: '#FFF7ED',
      link: '/customer-service'
    },
    { 
      id: 2, 
      icon: MessageSquare, 
      label: 'Tiket Support', 
      description: 'Buat tiket bantuan baru',
      color: '#10B981', 
      bgColor: '#F0FDF4',
      link: '/submit-ticket'
    },
    { 
      id: 3, 
      icon: HelpCircle, 
      label: 'Pusat Bantuan', 
      description: 'FAQ dan panduan lengkap',
      color: '#3B82F6', 
      bgColor: '#EFF6FF',
      link: '/help'
    },
    { 
      id: 4, 
      icon: FileText, 
      label: 'Syarat & Privasi', 
      description: 'Baca kebijakan kami',
      color: '#64748B', 
      bgColor: '#F8F9FA',
      link: '/terms-privacy'
    },
  ];

  return (
    <>
      {/* Header */}
      <div className="px-6 py-4 flex items-center gap-4 border-b bg-white" style={{ borderColor: '#E9ECEF' }}>
        <button 
          onClick={() => navigate('/')} 
          className="flex items-center justify-center w-10 h-10 rounded-full transition-all hover:bg-gray-100 active:scale-95"
        >
          <ArrowLeft size={24} style={{ color: '#1E293B' }} />
        </button>
        <h1 className="text-xl" style={{ color: '#1E293B', fontWeight: '700' }}>
          Layanan
        </h1>
      </div>

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto" style={{ backgroundColor: '#F8F9FA' }}>
        {/* Info Card */}
        <div className="px-6 py-4 mb-3 bg-white">
          <div className="flex items-start gap-3">
            <div 
              className="flex items-center justify-center w-10 h-10 rounded-full flex-shrink-0"
              style={{ 
                background: 'linear-gradient(135deg, #F97316 0%, #FB923C 100%)',
                boxShadow: '0 4px 12px rgba(249, 115, 22, 0.3)'
              }}
            >
              <MessageCircle size={20} style={{ color: '#FFFFFF' }} />
            </div>
            <div className="flex-1">
              <h2 className="text-base mb-0.5" style={{ color: '#1E293B', fontWeight: '700' }}>
                Kami Siap Membantu
              </h2>
              <p className="text-sm" style={{ color: '#64748B' }}>
                Tim support kami tersedia 24/7 untuk membantu Anda
              </p>
            </div>
          </div>
        </div>

        {/* Service Options */}
        <div className="px-6 pb-4">
          <h3 className="text-xs mb-2" style={{ color: '#64748B', fontWeight: '600' }}>
            PILIH LAYANAN
          </h3>
          <div className="space-y-2">
            {serviceItems.map((item) => (
              <button
                key={item.id}
                onClick={() => item.link && navigate(item.link)}
                className="w-full p-3 flex items-center gap-3 rounded-xl transition-all active:scale-98"
                style={{ 
                  backgroundColor: '#FFFFFF',
                  boxShadow: '0 1px 3px rgba(0, 0, 0, 0.05)'
                }}
              >
                <div 
                  className="flex items-center justify-center w-10 h-10 rounded-full flex-shrink-0"
                  style={{ backgroundColor: item.bgColor }}
                >
                  <item.icon size={20} style={{ color: item.color }} />
                </div>
                <div className="flex-1 text-left">
                  <div className="text-base" style={{ color: '#1E293B', fontWeight: '600' }}>
                    {item.label}
                  </div>
                  <div className="text-xs" style={{ color: '#64748B' }}>
                    {item.description}
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Rating Card */}
        <div className="px-6 pb-4">
          <div 
            className="p-3 rounded-xl"
            style={{ 
              backgroundColor: '#FFFFFF',
              boxShadow: '0 1px 3px rgba(0, 0, 0, 0.05)'
            }}
          >
            <div className="flex items-center gap-2 mb-2">
              <Star size={18} style={{ color: '#F59E0B' }} fill="#F59E0B" />
              <span className="text-sm" style={{ color: '#1E293B', fontWeight: '700' }}>
                Puas dengan layanan kami?
              </span>
            </div>
            <p className="text-xs mb-3" style={{ color: '#64748B' }}>
              Berikan rating untuk membantu kami meningkatkan kualitas layanan
            </p>
            <button
              onClick={() => navigate('/rate-service')}
              className="w-full py-2.5 rounded-xl transition-all active:scale-98"
              style={{ 
                backgroundColor: '#F97316',
                color: '#FFFFFF',
                fontWeight: '600',
                fontSize: '14px',
                boxShadow: '0 2px 8px rgba(249, 115, 22, 0.25)'
              }}
            >
              Beri Rating
            </button>
          </div>
        </div>
      </div>

      <style>{`
        .active\\:scale-98:active {
          transform: scale(0.98);
        }
        .active\\:scale-95:active {
          transform: scale(0.95);
        }
      `}</style>
    </>
  );
}